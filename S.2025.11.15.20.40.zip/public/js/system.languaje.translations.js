// system.languaje.translations.js – diccionario simple de traducciones (stub)
window.SystemTranslations = window.SystemTranslations || {
  es: {
    "header.domain": "Study.GODiOS.org",
  },
  en: {
    "header.domain": "Study.GODiOS.org",
  },
};
