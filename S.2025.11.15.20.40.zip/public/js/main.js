// main.js – enrutador principal de vistas dentro de <main>
window.Main = (function () {
  var currentView = null;

  var VIEW_TITLES = {
    navigator: "Navigation",
    results: "Search Results",
    focus: "Focus",
    preferences: "Preferences",
    changelog: "Changelog",
    login: "Sign in",
    register: "Register",
    forget: "Forget password",
    signout: "Sign out",
    account: "My account",
  };

  function documentReady(fn) {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", fn);
    } else {
      fn();
    }
  }

  function getMainContainer() {
    return document.getElementById("app-main") || document.querySelector("main");
  }

  function setViewTitle(name) {
    var pill = document.getElementById("view-title");
    if (!pill) return;
    var title = VIEW_TITLES[name] || "";
    if (!title) {
      pill.style.display = "none";
      return;
    }
    pill.textContent = title;
    pill.classList.add("view-title-pill");
    pill.style.display = "inline-block";
  }

  function clearMain(container) {
    if (!container) return;
    container.innerHTML = "";
  }

  function ensureStudyLayout(container) {
    if (!window.MainNavigator || typeof window.MainNavigator.ensureLayout !== "function") {
      return { root: container, nav: container, results: container, focus: container };
    }
    return window.MainNavigator.ensureLayout(container);
  }

  function showView(name, options) {
    options = options || {};
    var container = getMainContainer();
    if (!container) return;

    currentView = name;
    setViewTitle(name);

    var layoutPanels;

    if (name === "navigator" || name === "results" || name === "focus") {
      layoutPanels = ensureStudyLayout(container);
      if (!layoutPanels) return;

      if (name === "navigator") {
        if (window.MainNavigator && typeof window.MainNavigator.renderNav === "function") {
          window.MainNavigator.renderNav(layoutPanels.nav, options);
        }
        if (window.MainResults && typeof window.MainResults.render === "function") {
          window.MainResults.render(layoutPanels.results, options);
        }
        if (window.MainFocus && typeof window.MainFocus.render === "function") {
          window.MainFocus.render(layoutPanels.focus, options);
        }
      } else if (name === "results") {
        if (window.MainResults && typeof window.MainResults.render === "function") {
          window.MainResults.render(layoutPanels.results, options);
        }
      } else if (name === "focus") {
        if (window.MainFocus && typeof window.MainFocus.render === "function") {
          window.MainFocus.render(layoutPanels.focus, options);
        }
      }
      return;
    }

    // Vistas de panel único
    clearMain(container);

    var viewMap = {
      changelog: window.MainChangelog,
      preferences: window.MainPreferences,
      register: window.MainRegister,
      login: window.MainLogin,
      forget: window.MainForget,
      signout: window.MainSignout,
      account: window.MainAccount,
    };

    var mod = viewMap[name];
    if (mod && typeof mod.render === "function") {
      mod.render(container, options);
    } else {
      var div = document.createElement("div");
      div.className = "panel-single";
      div.innerHTML =
        '<h1>Not implemented</h1><p>View "' + String(name) + '" has no renderer yet.</p>';
      container.appendChild(div);
    }
  }

  function getCurrentView() {
    return currentView;
  }

  function init() {
    showView("navigator");
  }

  documentReady(init);

  return {
    showView: showView,
    getCurrentView: getCurrentView,
  };
})();
