// footer.js – inicialización genérica del footer + loader de corpus en el footer
(function () {
  function documentReady(fn) {
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", fn);
    } else {
      fn();
    }
  }

  function getFooterWrap() {
    return document.getElementById("app-footer");
  }

  function ensureLoaderNode() {
    var wrap = getFooterWrap();
    if (!wrap) return null;

    var loader = wrap.querySelector(".ftr-loader");
    if (!loader) {
      loader = document.createElement("div");
      loader.className = "ftr-loader";

      var span = document.createElement("span");
      span.setAttribute("data-footer-loader-pct", "1");
      span.textContent = "0%";

      loader.appendChild(span);
      wrap.appendChild(loader);
    }
    return loader;
  }

  var FooterLoader = {
    show: function (initialPct) {
      var wrap = getFooterWrap();
      if (!wrap) return;

      ensureLoaderNode();
      wrap.classList.add("ftr-loading");

      var v = typeof initialPct === "number" ? initialPct : 0;
      this.setProgress(v);
    },

    hide: function () {
      var wrap = getFooterWrap();
      if (!wrap) return;

      wrap.classList.remove("ftr-loading");
    },

    setProgress: function (pct) {
      var wrap = getFooterWrap();
      if (!wrap) return;

      var loader = ensureLoaderNode();
      if (!loader) return;

      var span = loader.querySelector("[data-footer-loader-pct]");
      if (!span) return;

      var v = parseInt(pct, 10);
      if (isNaN(v)) v = 0;
      if (v < 0) v = 0;
      if (v > 100) v = 100;

      span.textContent = v + "%";
    }
  };

  function init() {
    // Inicializar logo/versión como antes
    if (window.FooterLogo && typeof window.FooterLogo.init === "function") {
      window.FooterLogo.init();
    }

    // Exponer el controlador del loader de footer
    window.FooterLoader = FooterLoader;
  }

  documentReady(init);
})();
