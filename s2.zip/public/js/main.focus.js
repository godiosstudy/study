// main.focus.js – panel de contenido enfocado
window.MainFocus = (function () {
  function getPrefs() {
    try {
      if (window.PrefsStore && typeof window.PrefsStore.load === "function") {
        return window.PrefsStore.load() || {};
      }
    } catch (e) {}
    return {};
  }

  function getLang() {
    var prefs = getPrefs();
    return prefs.language || "es";
  }


  function render(container, options) {
    if (!container) return;

    var body = container;
    var lang = getLang();
    var opts = options || {};

    var l3 = opts.level_3 || "";
    var l4 = opts.level_4 || "";
    var l5 = opts.level_5 || "";
    var l6 = opts.level_6 || "";
    var l7 = opts.level_7 || "";

    // 🔁 Sincronizar breadcrumb con el foco actual ANTES de pintar el contenido
    try {
      if (window.Toolbar && typeof window.Toolbar.setFromFocus === "function") {
        window.Toolbar.setFromFocus(l3, l4, l5);
      } else if (window.ToolbarState) {
        window.ToolbarState.level_3 = l3 || window.ToolbarState.level_3 || "";
        window.ToolbarState.level_4 = l4 || window.ToolbarState.level_4 || "";
        window.ToolbarState.level_5 = l5 || window.ToolbarState.level_5 || "";
      }
    } catch (e) {}

    // Encabezado principal dentro del main (sin solapa invertida)
    var header = document.createElement("div");
    header.className = "main-view-header";

    var h1 = document.createElement("h1");
    h1.className = "main-view-title";

    if (l4 && l5 && l6) {
      h1.textContent = l4 + " " + l5 + ": " + l6;
    } else {
      h1.textContent = lang === "en" ? "Focused verse" : "Versículo enfocado";
    }

    body.innerHTML = "";
    header.appendChild(h1);
    body.appendChild(header);

    // Versículo (nivel 7)
    var content = document.createElement("div");
    content.className = "focus-main-text";

    if (l7) {
      content.textContent = l7;
    } else {
      content.textContent =
        lang === "en"
          ? "When you click an item in Navigation or Results, its Level 7 will appear here."
          : "Cuando hagas clic en un elemento de Navegación o Resultados, su Nivel 7 aparecerá aquí.";
    }

    body.appendChild(content);

    // Panel de acciones debajo del versículo (centrado)
    var actions = document.createElement("div");
    actions.className = "focus-actions";

    // Botón BACK principal (usa Lucide arrow-big-left-dash)
    var backBtn = document.createElement("button");
    backBtn.type = "button";
    backBtn.className = "focus-action-btn";

    var backIcon = document.createElement("i");
    backIcon.setAttribute("data-lucide", "arrow-big-left-dash");
    backBtn.appendChild(backIcon);

    backBtn.title =
      lang === "en" ? "Back to chapter" : "Volver al capítulo completo";

    backBtn.addEventListener("click", function () {
      if (window.Main && typeof window.Main.showView === "function") {
        window.Main.showView("navigator", {
          level_4: l4,
          level_5: l5,
        });
      }
    });

    actions.appendChild(backBtn);

    // Si hay usuario logueado, mostramos acciones con contadores
    
    function createStatAction(idBadge, iconName, labelEs, labelEn) {
      var btn = document.createElement("button");
      btn.type = "button";
      btn.className = "focus-action-btn";

      var iconEl = document.createElement("i");
      iconEl.setAttribute("data-lucide", iconName);
      btn.appendChild(iconEl);

      var badge = document.createElement("span");
      badge.className = "focus-action-badge";
      badge.id = idBadge;
      badge.textContent = "0"; // contador inicial
      btn.appendChild(badge);

      var label = lang === "en" ? (labelEn || "") : (labelEs || "");
      if (label) {
        btn.title = label;
        btn.setAttribute("aria-label", label);
      }

      // TODO: enganchar a Supabase para views/likes/notes/share
      return btn;
    }

    // Acciones extra: siempre visibles (views / likes / notes / share)
    actions.appendChild(
      createStatAction("focus-views", "eye", "Vistas", "Views")
    );
    actions.appendChild(
      createStatAction("focus-likes", "heart-plus", "Likes", "Likes")
    );
    actions.appendChild(
      createStatAction("focus-notes", "notebook-pen", "Notas", "Notes")
    );
    actions.appendChild(
      createStatAction("focus-share", "share-2", "Compartidos", "Shares")
    );

    body.appendChild(actions);

    // Activar Lucide en los iconos recién creados
    try {
      if (window.lucide && typeof window.lucide.createIcons === "function") {
        window.lucide.createIcons();
      }
    } catch (eLucide) {}
  }

  return { render: render };
})();
