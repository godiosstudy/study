// system.languaje.translations.js – diccionario simple de traducciones (stub)
window.SystemTranslations = window.SystemTranslations || {
  es: {
    "header.domain": "GODiOS",
  },
  en: {
    "header.domain": "GODiOS",
  },
};
